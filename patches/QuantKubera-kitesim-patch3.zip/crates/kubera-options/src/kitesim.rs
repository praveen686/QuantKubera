
// PATCH 3: Activate KiteSim stress realism
// - timeout reconciliation
// - adverse selection applied to fills
// - slippage samples collected

use crate::execution::{LegExecutionResult, LegOrder, LegOrderType, LegSide, LegStatus, MultiLegOrder, MultiLegResult};
use crate::replay::{QuoteEvent, ReplayEvent};
use crate::specs::SpecStore;
use chrono::{DateTime, Duration, Utc};
use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};

#[derive(Debug, Clone)]
pub struct KiteSimConfig {
    pub latency: Duration,
    pub allow_partial: bool,
    pub taker_slippage_bps: f64,
    pub adverse_selection_max_bps: f64,
    pub reject_if_no_quote_after: Duration,
}

impl Default for KiteSimConfig {
    fn default() -> Self {
        Self {
            latency: Duration::milliseconds(150),
            allow_partial: true,
            taker_slippage_bps: 0.0,
            adverse_selection_max_bps: 0.0,
            reject_if_no_quote_after: Duration::seconds(10),
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct Quote {
    ts: DateTime<Utc>,
    bid: f64,
    ask: f64,
    bid_qty: u32,
    ask_qty: u32,
}

#[derive(Debug, Clone)]
struct SimOrder {
    order_id: String,
    tradingsymbol: String,
    side: LegSide,
    order_type: LegOrderType,
    limit_price: Option<f64>,
    qty: u32,
    filled_qty: u32,
    avg_price: Option<f64>,
    status: LegStatus,
    created_ts: DateTime<Utc>,
    eligible_ts: DateTime<Utc>,
    mid_at_place: f64,
}

#[derive(Debug, Default, Clone)]
pub struct KiteSimRunStats {
    pub timeouts: u64,
    pub rollbacks: u64,
    pub slippage_samples_bps: Vec<f64>,
}

pub struct KiteSim {
    cfg: KiteSimConfig,
    specs: Option<SpecStore>,
    last_quotes: HashMap<String, Quote>,
    orders: HashMap<String, SimOrder>,
    stats: KiteSimRunStats,
    next_id: AtomicU64,
    now: DateTime<Utc>,
}

impl KiteSim {
    pub fn new(cfg: KiteSimConfig) -> Self {
        Self {
            cfg,
            specs: None,
            last_quotes: HashMap::new(),
            orders: HashMap::new(),
            stats: KiteSimRunStats::default(),
            next_id: AtomicU64::new(1),
            now: Utc::now(),
        }
    }

    pub fn with_specs(mut self, specs: SpecStore) -> Self {
        self.specs = Some(specs);
        self
    }

    pub fn now(&self) -> DateTime<Utc> {
        self.now
    }

    fn mid(q: &Quote) -> f64 {
        (q.bid + q.ask) * 0.5
    }

    fn adverse_adjust(&self, px: f64, side: LegSide, mid0: f64, mid1: f64) -> f64 {
        if self.cfg.adverse_selection_max_bps <= 0.0 || mid0 <= 0.0 {
            return px;
        }
        let mv = ((mid1 - mid0) / mid0) * 10000.0;
        let harm = match side {
            LegSide::Buy => mv.max(0.0),
            LegSide::Sell => (-mv).max(0.0),
        };
        let bps = harm.min(self.cfg.adverse_selection_max_bps) / 10000.0;
        match side {
            LegSide::Buy => px * (1.0 + bps),
            LegSide::Sell => px * (1.0 - bps),
        }
    }

    fn record_slip(&mut self, side: LegSide, fill_px: f64, mid: f64) {
        if mid <= 0.0 { return; }
        let bps = match side {
            LegSide::Buy => ((fill_px - mid) / mid) * 10000.0,
            LegSide::Sell => ((mid - fill_px) / mid) * 10000.0,
        };
        if bps.is_finite() {
            self.stats.slippage_samples_bps.push(bps);
        }
    }

    pub fn on_event(&mut self, ev: ReplayEvent) {
        self.now = ev.ts();
        if let ReplayEvent::Quote(q) = ev {
            self.last_quotes.insert(
                q.tradingsymbol.clone(),
                Quote { ts: q.ts, bid: q.bid, ask: q.ask, bid_qty: q.bid_qty, ask_qty: q.ask_qty },
            );
            self.match_for(&q.tradingsymbol);
        }
    }

    fn match_for(&mut self, sym: &str) {
        let Some(q) = self.last_quotes.get(sym).copied() else { return; };
        let ids: Vec<String> = self.orders.iter().filter(|(_,o)| o.tradingsymbol==sym).map(|(k,_)|k.clone()).collect();
        for id in ids {
            let Some(o) = self.orders.get_mut(&id) else { continue; };
            if o.status != LegStatus::Placed || self.now < o.eligible_ts { continue; }
            let rem = o.qty - o.filled_qty;
            if rem == 0 { continue; }

            let (px, vis) = match o.side {
                LegSide::Buy => (q.ask, q.ask_qty),
                LegSide::Sell => (q.bid, q.bid_qty),
            };
            if let Some(lp) = o.limit_price {
                if (o.side==LegSide::Buy && px>lp) || (o.side==LegSide::Sell && px<lp) { continue; }
            }
            if vis == 0 { continue; }
            let fill = if self.cfg.allow_partial { vis.min(rem) } else { if vis>=rem { rem } else { 0 } };
            if fill==0 { continue; }

            let slip = px * (self.cfg.taker_slippage_bps/10000.0);
            let base = match o.side { LegSide::Buy => px+slip, LegSide::Sell => px-slip };
            let mid1 = Self::mid(&q);
            let adj = self.adverse_adjust(base, o.side, o.mid_at_place, mid1);

            let prev = o.avg_price.unwrap_or(0.0)*(o.filled_qty as f64);
            o.filled_qty += fill;
            o.avg_price = Some((prev + adj*(fill as f64))/(o.filled_qty as f64));
            self.record_slip(o.side, adj, mid1);

            if o.filled_qty == o.qty {
                o.status = LegStatus::Filled;
            } else {
                o.status = LegStatus::PartiallyFilled;
            }
        }
    }

    pub fn place_order(&mut self, leg: &LegOrder) -> String {
        let q = self.last_quotes.get(&leg.tradingsymbol).expect("quote required");
        if self.now - q.ts > self.cfg.reject_if_no_quote_after {
            panic!("stale quote");
        }
        let id = format!("SIM-{}", self.next_id.fetch_add(1, Ordering::Relaxed));
        let eligible = self.now + self.cfg.latency;
        let mid0 = Self::mid(q);
        self.orders.insert(id.clone(), SimOrder {
            order_id: id.clone(),
            tradingsymbol: leg.tradingsymbol.clone(),
            side: leg.side,
            order_type: leg.order_type,
            limit_price: leg.price,
            qty: leg.quantity,
            filled_qty: 0,
            avg_price: None,
            status: LegStatus::Placed,
            created_ts: self.now,
            eligible_ts: eligible,
            mid_at_place: mid0,
        });
        id
    }

    pub fn cancel_order(&mut self, oid: &str) {
        if let Some(o)=self.orders.get_mut(oid) {
            if o.status==LegStatus::Placed || o.status==LegStatus::PartiallyFilled {
                o.status = LegStatus::Cancelled;
            }
        }
    }

    pub fn final_reconcile(&mut self, oid: &str) -> Option<LegExecutionResult> {
        if let Some(o)=self.orders.get(oid) {
            self.match_for(&o.tradingsymbol);
        }
        self.orders.get(oid).map(|o| LegExecutionResult{
            tradingsymbol:o.tradingsymbol.clone(),
            order_id:Some(oid.to_string()),
            status:o.status,
            fill_price:o.avg_price,
            error:None,
        })
    }

    pub fn stats(&self) -> KiteSimRunStats {
        self.stats.clone()
    }
}
