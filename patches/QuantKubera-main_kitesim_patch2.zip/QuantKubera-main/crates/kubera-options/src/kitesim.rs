//! KiteSim Patch 2 scaffold
//!
//! Adds hooks for:
//! - timeout reconciliation
//! - adverse selection knobs
//!
//! NOTE: Logic intentionally minimal; integrates cleanly with existing a13c3cf KiteSim.

use crate::execution::{LegExecutionResult, LegOrder, LegOrderType, LegSide, LegStatus, MultiLegOrder, MultiLegResult};
use crate::replay::{QuoteEvent, ReplayEvent};
use crate::specs::SpecStore;
use chrono::{DateTime, Duration, Utc};
use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, Ordering};

#[derive(Debug, Clone)]
pub struct KiteSimConfig {
    pub latency: Duration,
    pub allow_partial: bool,
    pub taker_slippage_bps: f64,
    pub adverse_selection_max_bps: f64,
    pub reject_if_no_quote_after: Duration,
}

impl Default for KiteSimConfig {
    fn default() -> Self {
        Self {
            latency: Duration::milliseconds(150),
            allow_partial: true,
            taker_slippage_bps: 0.0,
            adverse_selection_max_bps: 0.0,
            reject_if_no_quote_after: Duration::seconds(10),
        }
    }
}

#[derive(Debug, Default, Clone)]
pub struct KiteSimRunStats {
    pub timeouts: u64,
    pub rollbacks: u64,
    pub slippage_samples_bps: Vec<f64>,
}

pub struct KiteSim {
    cfg: KiteSimConfig,
    specs: Option<SpecStore>,
    next_id: AtomicU64,
    pub now: DateTime<Utc>,
}

impl KiteSim {
    pub fn new(cfg: KiteSimConfig) -> Self {
        Self {
            cfg,
            specs: None,
            next_id: AtomicU64::new(1),
            now: Utc::now(),
        }
    }

    pub fn with_specs(mut self, specs: SpecStore) -> Self {
        self.specs = Some(specs);
        self
    }

    pub fn final_reconcile(&mut self, _order_id: &str) -> Option<LegExecutionResult> {
        // Patch 2 hook: simulate "filled while cancelling"
        None
    }
}

pub struct MultiLegCoordinator {
    pub hedge_on_failure: bool,
}

impl MultiLegCoordinator {
    pub fn new() -> Self {
        Self { hedge_on_failure: true }
    }

    pub fn execute_with_feed_and_stats(
        &self,
        _sim: &mut KiteSim,
        _feed: &mut impl Iterator<Item = ReplayEvent>,
        order: &MultiLegOrder,
        _timeout: Duration,
    ) -> (MultiLegResult, KiteSimRunStats) {
        let stats = KiteSimRunStats::default();
        (
            MultiLegResult {
                strategy_name: order.strategy_name.clone(),
                leg_results: Vec::new(),
                all_filled: false,
                total_premium: 0.0,
            },
            stats,
        )
    }
}
